# Animals

!!! info
	All of these commands use a database of images collected by scraping reddit, this means you won't get the same 150 dogs that most bots offer through that one popular website. Currently I have about 15000 animal pictures saved.

!!! warning
    Do not underestimate how spammy your users will be with these commands, restricting them is recommended.

| Name | Example | Usage |
| :--- | :--- | :--- |
| cat | !cat | Gives you a random cat. |
| dog | !dog | Gives you a random dog. |
| aww | !aww | Gives you a random cute animal. |
| catbomb | !catbomb | Gives you 5 links instead of just one, only use this if you LOVE cats! |
| dogbomb | !dogbomb | ^ but dogs. |
| awwbomb | !awwbomb | ^ but just cute animals. |

